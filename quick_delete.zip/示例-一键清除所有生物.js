H.showOutput(false);
var text="♂";

var lay=HLayout.newClass();
var btn=HButton.newClass();

lay.setLayoutSize(-1,-1);
lay.setGravity(5|48);
btn.setButtonText(text);
btn.setOnClickListener("onClick()");

lay.addView(btn);
H.addView(lay);

function onClick()
{
  if(builder.IsOpenFile()&&builder.IsHasMobs())
  {
    for(;;)
    {
      builder.removeMob(0);
      if(!builder.IsHasMobs())
      {
        break;
      }
    }
    H.toast("完成",0);
  }
  else
  {
    H.alert("提示","当前没有生物","#FFFFFF",false,"关闭");
  }
}